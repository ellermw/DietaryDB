const express = require('express');
const router = express.Router();
const { authenticateToken, authorizeRole } = require('../middleware/auth');
const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST || 'dietary_postgres',
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME || 'dietary_db',
  user: process.env.DB_USER || 'dietary_user',
  password: process.env.DB_PASSWORD || 'DietarySecurePass2024!',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

// Get all categories with item counts
router.get('/', authenticateToken, async (req, res) => {
  try {
    // Ensure categories table exists
    await pool.query(`
      CREATE TABLE IF NOT EXISTS categories (
        category_id SERIAL PRIMARY KEY,
        category_name VARCHAR(100) UNIQUE NOT NULL,
        item_count INTEGER DEFAULT 0,
        created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Sync categories from items table
    await pool.query(`
      INSERT INTO categories (category_name, item_count)
      SELECT DISTINCT category, 0 FROM items 
      WHERE category IS NOT NULL 
      ON CONFLICT (category_name) DO NOTHING
    `);

    // Update item counts
    await pool.query(`
      UPDATE categories c
      SET item_count = (
        SELECT COUNT(*) FROM items i 
        WHERE i.category = c.category_name AND i.is_active = true
      )
    `);

    // Get all categories
    const result = await pool.query(`
      SELECT category_id, category_name, item_count
      FROM categories
      ORDER BY category_name
    `);
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({ message: 'Error fetching categories' });
  }
});

// Add new category
router.post('/', [authenticateToken, authorizeRole('Admin')], async (req, res) => {
  const { category_name } = req.body;
  
  if (!category_name || category_name.trim() === '') {
    return res.status(400).json({ message: 'Category name is required' });
  }
  
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS categories (
        category_id SERIAL PRIMARY KEY,
        category_name VARCHAR(100) UNIQUE NOT NULL,
        item_count INTEGER DEFAULT 0,
        created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    const result = await pool.query(
      'INSERT INTO categories (category_name, item_count) VALUES ($1, 0) RETURNING *',
      [category_name.trim()]
    );
    
    res.status(201).json({ 
      message: 'Category created successfully',
      category: result.rows[0] 
    });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(400).json({ message: 'Category already exists' });
    }
    console.error('Error adding category:', error);
    res.status(500).json({ message: 'Error adding category' });
  }
});

// Delete category
router.delete('/:id', [authenticateToken, authorizeRole('Admin')], async (req, res) => {
  try {
    // Get category name
    const catResult = await pool.query(
      'SELECT category_name, item_count FROM categories WHERE category_id = $1',
      [req.params.id]
    );
    
    if (catResult.rows.length === 0) {
      return res.status(404).json({ message: 'Category not found' });
    }
    
    const category = catResult.rows[0];
    
    // Check if category has items
    const itemCount = await pool.query(
      'SELECT COUNT(*) as count FROM items WHERE category = $1 AND is_active = true',
      [category.category_name]
    );
    
    if (parseInt(itemCount.rows[0].count) > 0) {
      return res.status(400).json({ 
        message: `Cannot delete category "${category.category_name}" with ${itemCount.rows[0].count} active items`
      });
    }
    
    // Delete category
    await pool.query('DELETE FROM categories WHERE category_id = $1', [req.params.id]);
    
    res.json({ message: `Category "${category.category_name}" deleted successfully` });
  } catch (error) {
    console.error('Error deleting category:', error);
    res.status(500).json({ message: 'Error deleting category' });
  }
});

module.exports = router;
