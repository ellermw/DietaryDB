const express = require('express');
const router = express.Router();
const { authenticateToken, authorizeRole } = require('../middleware/auth');
const { exec } = require('child_process');
const fs = require('fs').promises;
const path = require('path');
const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST || 'dietary_postgres',
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME || 'dietary_db',
  user: process.env.DB_USER || 'dietary_user',
  password: process.env.DB_PASSWORD || 'DietarySecurePass2024!',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

// Backup directories
const BACKUP_DIR = '/backups';
const ACTUAL_BACKUP_DIR = '/opt/dietarydb/backups/databases';

// Progress tracking for tasks
const progressTrackers = new Map();

// Helper function to send progress updates
function updateProgress(taskId, message, progress) {
  if (progressTrackers.has(taskId)) {
    const tracker = progressTrackers.get(taskId);
    tracker.logs.push({ message, timestamp: new Date().toISOString() });
    tracker.progress = progress;
    if (progress === 100 || progress === -1) {
      tracker.completed = true;
    }
  }
}

// Get task progress
router.get('/progress/:taskId', authenticateToken, async (req, res) => {
  const taskId = req.params.taskId;
  
  if (!progressTrackers.has(taskId)) {
    progressTrackers.set(taskId, {
      logs: [],
      progress: 0,
      completed: false
    });
  }
  
  const tracker = progressTrackers.get(taskId);
  res.json(tracker);
  
  // Clean up completed tasks after retrieval
  if (tracker.completed) {
    setTimeout(() => progressTrackers.delete(taskId), 60000); // Clean up after 1 minute
  }
});

// Get database statistics
router.get('/database/stats', authenticateToken, async (req, res) => {
  try {
    const stats = await pool.query(`
      SELECT 
        (SELECT COUNT(*) FROM users WHERE is_active = true) as active_users,
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM items WHERE is_active = true) as active_items,
        (SELECT COUNT(DISTINCT category) FROM items WHERE category IS NOT NULL) as categories,
        pg_database_size(current_database()) as database_size
    `);
    
    const dbSize = parseInt(stats.rows[0].database_size);
    const formattedSize = formatBytes(dbSize);
    
    res.json({
      ...stats.rows[0],
      database_size: formattedSize
    });
  } catch (error) {
    console.error('Error fetching database stats:', error);
    res.status(500).json({ message: 'Error fetching database statistics' });
  }
});

// Get maintenance schedule
router.get('/maintenance/schedule', authenticateToken, async (req, res) => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS maintenance_schedule (
        id SERIAL PRIMARY KEY,
        cron_expression VARCHAR(50) DEFAULT '0 2 * * *',
        is_enabled BOOLEAN DEFAULT false,
        last_run TIMESTAMP,
        created_by VARCHAR(100),
        created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    const result = await pool.query('SELECT * FROM maintenance_schedule ORDER BY id DESC LIMIT 1');
    
    if (result.rows.length === 0) {
      return res.json({
        cron_expression: '0 2 * * *',
        is_enabled: false,
        last_run: null
      });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching maintenance schedule:', error);
    res.status(500).json({ message: 'Error fetching maintenance schedule' });
  }
});

// Update maintenance schedule
router.put('/maintenance/schedule', [authenticateToken, authorizeRole('Admin')], async (req, res) => {
  const { cron_expression, is_active } = req.body;
  
  try {
    await pool.query(`
      INSERT INTO maintenance_schedule (id, cron_expression, is_enabled, created_by)
      VALUES (1, $1, $2, $3)
      ON CONFLICT (id) DO UPDATE SET
        cron_expression = $1,
        is_enabled = $2,
        created_by = $3,
        created_date = CURRENT_TIMESTAMP
    `, [cron_expression, is_active, req.user.username]);
    
    res.json({ message: 'Maintenance schedule updated successfully' });
  } catch (error) {
    console.error('Error updating maintenance schedule:', error);
    res.status(500).json({ message: 'Error updating maintenance schedule' });
  }
});

// Run maintenance with live progress
router.post('/maintenance/run', [authenticateToken, authorizeRole('Admin')], async (req, res) => {
  const taskId = `maintenance_${Date.now()}`;
  
  // Initialize progress tracker
  progressTrackers.set(taskId, {
    logs: [],
    progress: 0,
    completed: false
  });
  
  // Start async maintenance
  (async () => {
    try {
      updateProgress(taskId, 'Starting maintenance tasks...', 10);
      
      updateProgress(taskId, 'Optimizing database (VACUUM ANALYZE)...', 30);
      await pool.query('VACUUM ANALYZE');
      
      updateProgress(taskId, 'Cleaning old audit logs...', 60);
      const cleanupResult = await pool.query(
        `DELETE FROM activity_log WHERE created_date < NOW() - INTERVAL '90 days'`
      );
      updateProgress(taskId, `Cleaned ${cleanupResult.rowCount} old audit logs`, 80);
      
      updateProgress(taskId, 'Updating maintenance log...', 90);
      await pool.query(
        `UPDATE maintenance_schedule SET last_run = CURRENT_TIMESTAMP WHERE id = 1`
      );
      
      updateProgress(taskId, 'Maintenance completed successfully!', 100);
    } catch (error) {
      updateProgress(taskId, `Error: ${error.message}`, -1);
    }
  })();
  
  res.json({ 
    message: 'Maintenance started',
    taskId
  });
});

// Create backup with live progress
router.post('/backup/create', [authenticateToken, authorizeRole('Admin')], async (req, res) => {
  const taskId = `backup_${Date.now()}`;
  
  // Initialize progress tracker
  progressTrackers.set(taskId, {
    logs: [],
    progress: 0,
    completed: false
  });
  
  // Start async backup
  (async () => {
    try {
      updateProgress(taskId, 'Preparing backup...', 10);
      
      // Ensure directories exist
      await fs.mkdir(ACTUAL_BACKUP_DIR, { recursive: true });
      await fs.mkdir(BACKUP_DIR, { recursive: true });
      
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('.')[0];
      const filename = `dietary_backup_${timestamp}.sql`;
      const filepath = path.join(ACTUAL_BACKUP_DIR, filename);
      
      updateProgress(taskId, 'Creating database dump...', 30);
      
      const dumpCommand = `PGPASSWORD="${process.env.DB_PASSWORD}" pg_dump -h dietary_postgres -U ${process.env.DB_USER} -d ${process.env.DB_NAME} -f ${filepath}`;
      
      await new Promise((resolve, reject) => {
        exec(dumpCommand, (error, stdout, stderr) => {
          if (error) {
            reject(error);
          } else {
            resolve();
          }
        });
      });
      
      updateProgress(taskId, 'Verifying backup...', 70);
      
      const stats = await fs.stat(filepath);
      const size = formatBytes(stats.size);
      
      updateProgress(taskId, `Backup created: ${filename} (${size})`, 90);
      updateProgress(taskId, 'Backup completed successfully!', 100);
    } catch (error) {
      updateProgress(taskId, `Error: ${error.message}`, -1);
    }
  })();
  
  res.json({ 
    message: 'Backup started',
    taskId
  });
});

// List backups
router.get('/backup/list', authenticateToken, async (req, res) => {
  try {
    // Check both directories
    const backupDirs = [ACTUAL_BACKUP_DIR, BACKUP_DIR];
    const allBackups = [];
    const seen = new Set();
    
    for (const dir of backupDirs) {
      try {
        const files = await fs.readdir(dir);
        const sqlFiles = files.filter(f => f.endsWith('.sql'));
        
        for (const file of sqlFiles) {
          if (seen.has(file)) continue;
          seen.add(file);
          
          const filepath = path.join(dir, file);
          try {
            const stats = await fs.stat(filepath);
            if (stats.isFile()) {
              allBackups.push({
                filename: file,
                size: stats.size,
                size_formatted: formatBytes(stats.size),
                created: stats.birthtime || stats.ctime,
                path: filepath
              });
            }
          } catch (e) {
            // Skip files we can't stat
          }
        }
      } catch (e) {
        // Directory might not exist
      }
    }
    
    allBackups.sort((a, b) => new Date(b.created) - new Date(a.created));
    res.json(allBackups);
  } catch (error) {
    console.error('Error listing backups:', error);
    res.status(500).json({ message: 'Error listing backups' });
  }
});

// Delete backup
router.delete('/backup/:filename', [authenticateToken, authorizeRole('Admin')], async (req, res) => {
  try {
    const { filename } = req.params;
    
    // Validate filename
    if (!filename.match(/^dietary_backup_[\d\-T]+\.sql$/)) {
      return res.status(400).json({ message: 'Invalid backup filename' });
    }
    
    // Try to delete from both locations
    const paths = [
      path.join(ACTUAL_BACKUP_DIR, filename),
      path.join(BACKUP_DIR, filename)
    ];
    
    let deleted = false;
    for (const filepath of paths) {
      try {
        await fs.unlink(filepath);
        deleted = true;
      } catch (e) {
        // File might not exist in this location
      }
    }
    
    if (!deleted) {
      return res.status(404).json({ message: 'Backup file not found' });
    }
    
    res.json({ message: 'Backup deleted successfully' });
  } catch (error) {
    console.error('Error deleting backup:', error);
    res.status(500).json({ message: 'Error deleting backup' });
  }
});

// Download backup
router.get('/backup/download/:filename', authenticateToken, async (req, res) => {
  try {
    const { filename } = req.params;
    
    // Validate filename
    if (!filename.match(/^dietary_backup_[\d\-T]+\.sql$/)) {
      return res.status(400).json({ message: 'Invalid backup filename' });
    }
    
    // Check both locations
    const paths = [
      path.join(ACTUAL_BACKUP_DIR, filename),
      path.join(BACKUP_DIR, filename)
    ];
    
    let foundPath = null;
    for (const filepath of paths) {
      try {
        await fs.access(filepath);
        foundPath = filepath;
        break;
      } catch (e) {
        // File doesn't exist here
      }
    }
    
    if (!foundPath) {
      return res.status(404).json({ message: 'Backup file not found' });
    }
    
    res.download(foundPath, filename);
  } catch (error) {
    console.error('Error downloading backup:', error);
    res.status(500).json({ message: 'Error downloading backup' });
  }
});

// Restore backup with progress
router.post('/backup/restore/:filename', [authenticateToken, authorizeRole('Admin')], async (req, res) => {
  const taskId = `restore_${Date.now()}`;
  
  // Initialize progress tracker
  progressTrackers.set(taskId, {
    logs: [],
    progress: 0,
    completed: false
  });
  
  const { filename } = req.params;
  
  if (!filename.match(/^dietary_backup_[\d\-T]+\.sql$/)) {
    return res.status(400).json({ message: 'Invalid backup filename' });
  }
  
  // Start async restore
  (async () => {
    try {
      updateProgress(taskId, 'Locating backup file...', 10);
      
      // Find the backup file
      const paths = [
        path.join(ACTUAL_BACKUP_DIR, filename),
        path.join(BACKUP_DIR, filename)
      ];
      
      let backupPath = null;
      for (const filepath of paths) {
        try {
          await fs.access(filepath);
          backupPath = filepath;
          break;
        } catch (e) {
          // Continue searching
        }
      }
      
      if (!backupPath) {
        updateProgress(taskId, 'Error: Backup file not found', -1);
        return;
      }
      
      updateProgress(taskId, 'Creating pre-restore backup...', 30);
      
      // Create a backup before restore
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('.')[0];
      const preRestoreFile = path.join(ACTUAL_BACKUP_DIR, `pre_restore_${timestamp}.sql`);
      
      const backupCmd = `PGPASSWORD="${process.env.DB_PASSWORD}" pg_dump -h dietary_postgres -U ${process.env.DB_USER} -d ${process.env.DB_NAME} -f ${preRestoreFile}`;
      
      await new Promise((resolve, reject) => {
        exec(backupCmd, (error) => {
          if (error) reject(error);
          else resolve();
        });
      });
      
      updateProgress(taskId, 'Restoring database...', 60);
      
      // Restore the backup
      const restoreCmd = `PGPASSWORD="${process.env.DB_PASSWORD}" psql -h dietary_postgres -U ${process.env.DB_USER} -d ${process.env.DB_NAME} -f ${backupPath}`;
      
      await new Promise((resolve, reject) => {
        exec(restoreCmd, (error) => {
          if (error) reject(error);
          else resolve();
        });
      });
      
      updateProgress(taskId, 'Restore completed successfully!', 100);
    } catch (error) {
      updateProgress(taskId, `Error: ${error.message}`, -1);
    }
  })();
  
  res.json({ 
    message: 'Restore started',
    taskId
  });
});

// Upload and restore backup  
router.post('/backup/upload-restore', [authenticateToken, authorizeRole('Admin')], async (req, res) => {
  res.status(501).json({ 
    message: 'File upload not implemented. Please copy backup file to /opt/dietarydb/backups/databases/ and use the restore endpoint.' 
  });
});

function formatBytes(bytes, decimals = 2) {
  if (!bytes || bytes === 0) return '0 MB';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

module.exports = router;
